package com.fiddle.soap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.fiddle.soap.storage.StorageProperties;

@SpringBootApplication
@EnableConfigurationProperties(StorageProperties.class)
public class SoapFiddleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoapFiddleApplication.class, args);
	}
}
