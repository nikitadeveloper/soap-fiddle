package com.fiddle.soap.controller;

import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.reficio.ws.builder.SoapBuilder;
import org.reficio.ws.builder.SoapOperation;
import org.reficio.ws.builder.core.Wsdl;
import org.reficio.ws.client.core.SoapClient;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.fiddle.soap.model.SoapFiddleModel;
import com.fiddle.soap.model.SoapFiddleUIBean;


@Controller
@SessionAttributes("soapFiddleModel")
@RequestMapping("/soapFiddle")
public class SoapFiddleController {
	
	@GetMapping("/getOperations")
    @ResponseBody
    public List<SoapOperation> getOperationsFromBinding(Model model, @RequestParam("bindingName") String bindingName) {
    	System.out.println("got hit"+model.containsAttribute("soapFiddleModel")+bindingName);

    	List<SoapOperation> operations = null;
		if (model.containsAttribute("soapFiddleModel")) {
			SoapFiddleModel soapFiddleModel= (SoapFiddleModel) model.asMap().get("soapFiddleModel");
			Wsdl wsdl = soapFiddleModel.getParsedWsdl();
			SoapBuilder builder = wsdl.binding().localPart(bindingName).find();
			operations = builder.getOperations();
			System.out.println(operations);
		}

    	return operations;
    }
    
	@PostMapping("/postDataToUrl")
    @ResponseBody 
    public SoapFiddleUIBean postDataToUrl(Model model, @RequestBody SoapFiddleUIBean soapFiddleUIBean) {
		if (model.containsAttribute("soapFiddleModel")) {
			SoapFiddleModel soapFiddleModel= (SoapFiddleModel) model.asMap().get("soapFiddleModel");
			Wsdl wsdl = soapFiddleModel.getParsedWsdl();
			SoapBuilder builder = wsdl.binding().localPart(soapFiddleUIBean.getBindingName()).find();
			SoapOperation operation = builder.operation().name(soapFiddleUIBean.getOperationName()).find();
			SoapClient client = SoapClient.builder().endpointUri(soapFiddleUIBean.getUrlForPost()).build();
			String response = client.post(operation.getSoapAction(), soapFiddleUIBean.getSoapRequest());
			String formattedResponse;
			try {
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
				dbf.setValidating(false);
				DocumentBuilder db = dbf.newDocumentBuilder();
				InputSource is = new InputSource(new StringReader(response));
				Document doc = db.parse(is);
				
				Transformer tf = TransformerFactory.newInstance().newTransformer();
				tf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
				tf.setOutputProperty(OutputKeys.INDENT, "yes");
				Writer out = new StringWriter();
				tf.transform(new DOMSource(doc), new StreamResult(out));
				formattedResponse=out.toString();
			} catch (Exception e) {
				formattedResponse=response;
				e.printStackTrace();
			}
			soapFiddleUIBean.setSoapResponse(formattedResponse);		
		}

    	return soapFiddleUIBean;
    }
	
	@PostMapping("/generateSampleRequest")
    @ResponseBody 
    public SoapFiddleUIBean generateSampleRequest(Model model, @RequestBody SoapFiddleUIBean soapFiddleUIBean) {
		if (model.containsAttribute("soapFiddleModel")) {
			SoapFiddleModel soapFiddleModel= (SoapFiddleModel) model.asMap().get("soapFiddleModel");
			Wsdl wsdl = soapFiddleModel.getParsedWsdl();
			SoapBuilder builder = wsdl.binding().localPart(soapFiddleUIBean.getBindingName()).find();
			SoapOperation operation = builder.operation().name(soapFiddleUIBean.getOperationName()).find();
			soapFiddleUIBean.setSoapRequest(builder.buildInputMessage(operation));		
		}

    	return soapFiddleUIBean;
    }
	
	
	@GetMapping("")
	public String soapResponse(String url, String request1, Model model) {
		/*System.out.println(model.containsAttribute("soapFiddleModel"));
		if (model.containsAttribute("soapFiddleModel")) {
			SoapFiddleModel soapFiddleModel= (SoapFiddleModel) model.asMap().get("soapFiddleModel");
			Wsdl wsdl = soapFiddleModel.getParsedWsdl();
		}*/
		return "soapFiddle";
	}

}
