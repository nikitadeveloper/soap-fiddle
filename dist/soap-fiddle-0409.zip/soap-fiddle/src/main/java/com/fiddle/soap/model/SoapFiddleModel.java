package com.fiddle.soap.model;

import org.reficio.ws.builder.core.Wsdl;

public class SoapFiddleModel {
	
	public SoapFiddleModel(Wsdl parsedWsdl) {
		super();
		this.setParsedWsdl(parsedWsdl);
	}

	public Wsdl getParsedWsdl() {
		return parsedWsdl;
	}

	public void setParsedWsdl(Wsdl parsedWsdl) {
		this.parsedWsdl = parsedWsdl;
	}

	private Wsdl parsedWsdl;


}
